# 🚀 Life Fractal Intelligence - Render Deployment
# Automated setup script

Write-Host ""
Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  🌀 LIFE FRACTAL - RENDER DEPLOYMENT" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Check for Git
Write-Host "Checking for Git..." -ForegroundColor Yellow
$git = Get-Command git -ErrorAction SilentlyContinue
if (-not $git) {
    Write-Host "❌ Git not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please install Git from: https://git-scm.com/download/win" -ForegroundColor Yellow
    Write-Host "Then restart PowerShell and run this script again." -ForegroundColor Yellow
    Write-Host ""
    pause
    exit
}
Write-Host "✅ Git found" -ForegroundColor Green

# Configure Git
Write-Host ""
Write-Host "Configuring Git..." -ForegroundColor Yellow
git config --global user.email "onlinediscountsllc@gmail.com"
git config --global user.name "Luke"
Write-Host "✅ Git configured" -ForegroundColor Green

# Check files
Write-Host ""
Write-Host "Checking files..." -ForegroundColor Yellow
if (-not (Test-Path "app.py")) {
    Write-Host "❌ app.py not found!" -ForegroundColor Red
    Write-Host "Make sure you're running this from the render-deployment folder" -ForegroundColor Yellow
    pause
    exit
}
if (-not (Test-Path "requirements.txt")) {
    Write-Host "❌ requirements.txt not found!" -ForegroundColor Red
    pause
    exit
}
if (-not (Test-Path "render.yaml")) {
    Write-Host "❌ render.yaml not found!" -ForegroundColor Red
    pause
    exit
}
Write-Host "✅ All files found" -ForegroundColor Green

# Initialize Git
Write-Host ""
Write-Host "Setting up Git repository..." -ForegroundColor Yellow
if (Test-Path ".git") {
    Write-Host "⚠️  Git already initialized, skipping..." -ForegroundColor Yellow
} else {
    git init
    Write-Host "✅ Git initialized" -ForegroundColor Green
}

# Add files
Write-Host ""
Write-Host "Adding files to Git..." -ForegroundColor Yellow
git add .
Write-Host "✅ Files staged" -ForegroundColor Green

# Commit
Write-Host ""
Write-Host "Creating commit..." -ForegroundColor Yellow
git commit -m "Deploy Life Fractal Intelligence to Render" -ErrorAction SilentlyContinue
Write-Host "✅ Commit created" -ForegroundColor Green

Write-Host ""
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host "  ✅ LOCAL SETUP COMPLETE!" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""

# Next steps
Write-Host "NEXT STEPS:" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Create GitHub repository:" -ForegroundColor White
Write-Host "   Go to: https://github.com/new" -ForegroundColor Yellow
Write-Host "   Name: life-fractal-app" -ForegroundColor Yellow
Write-Host "   Keep it Public" -ForegroundColor Yellow
Write-Host "   Click 'Create repository'" -ForegroundColor Yellow
Write-Host ""

Write-Host "2. Push your code to GitHub:" -ForegroundColor White
Write-Host "   After creating the repo, GitHub will show you commands." -ForegroundColor Yellow
Write-Host "   Run these commands in this same PowerShell window:" -ForegroundColor Yellow
Write-Host ""
Write-Host "   git remote add origin https://github.com/YOUR-USERNAME/life-fractal-app.git" -ForegroundColor Magenta
Write-Host "   git branch -M main" -ForegroundColor Magenta
Write-Host "   git push -u origin main" -ForegroundColor Magenta
Write-Host ""

Write-Host "3. Deploy on Render:" -ForegroundColor White
Write-Host "   a) Go to: https://render.com" -ForegroundColor Yellow
Write-Host "   b) Sign up with GitHub (free)" -ForegroundColor Yellow
Write-Host "   c) Click 'New +' → 'Blueprint'" -ForegroundColor Yellow
Write-Host "   d) Connect your life-fractal-app repo" -ForegroundColor Yellow
Write-Host "   e) Click 'Apply'" -ForegroundColor Yellow
Write-Host "   f) Wait 3-5 minutes" -ForegroundColor Yellow
Write-Host "   g) YOUR APP IS LIVE! 🎉" -ForegroundColor Yellow
Write-Host ""

Write-Host "Your app will be at:" -ForegroundColor Cyan
Write-Host "https://life-fractal-intelligence.onrender.com" -ForegroundColor Green
Write-Host ""

Write-Host "═══════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# Offer to open GitHub
$openGitHub = Read-Host "Open GitHub in browser to create repo now? (Y/n)"
if ($openGitHub -ne 'n' -and $openGitHub -ne 'N') {
    Start-Process "https://github.com/new"
    Write-Host ""
    Write-Host "✅ GitHub opened in browser" -ForegroundColor Green
    Write-Host "Create your repo, then come back here for the git commands!" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Waiting for you to create GitHub repo and run the git commands..." -ForegroundColor Yellow
Write-Host "Press any key when ready to open Render..." -ForegroundColor Yellow
pause

# Offer to open Render
Write-Host ""
$openRender = Read-Host "Open Render in browser to deploy? (Y/n)"
if ($openRender -ne 'n' -and $openRender -ne 'N') {
    Start-Process "https://render.com"
    Write-Host ""
    Write-Host "✅ Render opened in browser" -ForegroundColor Green
}

Write-Host ""
Write-Host "🎉 You're all set! Follow the Render steps to complete deployment." -ForegroundColor Green
Write-Host ""
pause

# Life Fractal v8 - Ultimate Deployment Script
# Run this in PowerShell

Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "   DEPLOY v8 - ULTIMATE VERSION" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "New Features:" -ForegroundColor Yellow
Write-Host "  [+] Llama 3 AI Chat" -ForegroundColor Green
Write-Host "  [+] Voice Control" -ForegroundColor Green
Write-Host "  [+] Swarm Intelligence" -ForegroundColor Green
Write-Host "  [+] CBT Analysis" -ForegroundColor Green
Write-Host "  [+] Mayan Calendar" -ForegroundColor Green
Write-Host "  [+] Full Z(T) Equation" -ForegroundColor Green
Write-Host "  [+] Forgot Password" -ForegroundColor Green
Write-Host "  [+] Enhanced Security" -ForegroundColor Green
Write-Host "  [+] NO Emoji Issues" -ForegroundColor Green
Write-Host ""

Set-Location "C:\Users\Luke\Desktop\planner"

Write-Host "Staging files..." -ForegroundColor Yellow
git add app.py requirements.txt render.yaml runtime.txt

Write-Host ""
Write-Host "Committing..." -ForegroundColor Yellow
git commit -m "v8 Ultimate - Llama 3, Voice Control, Swarm Intelligence, Fixed emoji rendering"

Write-Host ""
Write-Host "Pushing to GitHub..." -ForegroundColor Yellow
git push

Write-Host ""
Write-Host "=====================================" -ForegroundColor Green
Write-Host "   DEPLOYED! Render is building..." -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Green
Write-Host ""
Write-Host "Watch build: https://dashboard.render.com" -ForegroundColor Cyan
Write-Host "Your app: https://planner-1-pyd9.onrender.com" -ForegroundColor Cyan
Write-Host ""
Write-Host "Build time: ~3 minutes" -ForegroundColor Yellow
Write-Host ""

Pause
